(function ($) {
    "use strict";
	
	$(window).on("load", function() {
	    $(".preloader").fadeOut();
    });

})(jQuery);